﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad1
{
    public class Calculator
    {
        public double A { get; set; }
        public double B { get; set; }
        public double C { get; set; }

        public void CalculatePerimetur()
        {
            Console.WriteLine($"Perimetur= a+b+c={A + B + C}");
        }
        public void CalculateTriagle()
        {
            Console.WriteLine($"Lice na triugulnik=(a + b + c) / 2={(A + B + C) / 2}");
        }
    }
}
