﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Calculator calculator = new Calculator();
            Console.Write("Vuvedi A=");
            calculator.A=double.Parse(Console.ReadLine());
            Console.Write("Vuvedi B=");
            calculator.B=double.Parse(Console.ReadLine());
            Console.Write("Vuvedi C=");
            calculator.C=double.Parse(Console.ReadLine());

            if (calculator.A + calculator.B > calculator.C && calculator.A + calculator.C > calculator.B && calculator.B + calculator.C > calculator.A)
            {
                calculator.CalculatePerimetur();

                calculator.CalculateTriagle();
            }
            else
            {
               
                Console.WriteLine("Greshka");
            }
        }
    }
}
