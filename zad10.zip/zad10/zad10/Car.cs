﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad10
{
    public class Car
    {
        public string Marka { get; set; }
        public string Model { get; set; }
        public string RegistrationNumber { get; set; }
        public int Date {  get; set; }

        

        public Car(string marka, string model, string registrationNumber, int date)
        {
            Marka = marka;
            Model = model;
            RegistrationNumber = registrationNumber;
            Date = date;
        }

        public void PrintMarkaModel()
        {
            Console.WriteLine($"{Marka} {Model}: Brym-brum-brum");
        }
        public void PrintEco()
        {
            if (Date > 2000)
            {
                Console.WriteLine("ECO CAR");
            }
            else
            {
                Console.WriteLine("Im not eco");
            }
        }
        public void PrintAll()
        {
            Console.WriteLine(Marka+" "+Model+" "+" "+ RegistrationNumber + " "+Date);
        }
        
        
    }
}
