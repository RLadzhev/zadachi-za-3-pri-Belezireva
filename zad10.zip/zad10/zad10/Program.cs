﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace zad10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Car> cars = new List<Car>();

            Console.Write("Колко коли ще се състезават: ");
            int number = int.Parse(Console.ReadLine());
        
            for (int i = 0; i < number; i++)
            {
                Console.WriteLine($"Кола {i + 1}:");

                Console.Write("Марка: ");
                string brand = Console.ReadLine();

                Console.Write("Модел: ");
                string model = Console.ReadLine();

                Console.Write("Рег. номер: ");
                string registrationNumber = Console.ReadLine();

                Console.Write("Година: ");
                int year = int.Parse(Console.ReadLine());

                Car car = new Car(brand, model, registrationNumber, year);
                cars.Add(car);
            }
            foreach (Car car in cars)
            {
                Console.WriteLine("Кола:");
                car.PrintAll();
                car.PrintMarkaModel();
                car.PrintEco();
            }
            Console.WriteLine($"Брой състезателио: {cars.Count}");
        }
    }
}
