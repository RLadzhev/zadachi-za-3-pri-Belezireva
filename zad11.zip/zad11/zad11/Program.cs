﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] numberdiapazon = new double[20];
            int number = 0;

            Console.WriteLine("Vuvejdai chisla (0 za krai)");
            for (int i = 0; i < 20; i++)
            {
                double chislo = double.Parse(Console.ReadLine());
                if (chislo == 0) break;
                numberdiapazon[i] = chislo;
                number++;
            }

            int praznielementi = 20 - number;
            Console.WriteLine($"Prazni elementi: {praznielementi}");

            if (number > 0)
            {
                int min = 0;
                int max = 0;
                for (int i = 1; i < number; i++)
                {
                    if (numberdiapazon[i] < numberdiapazon[min]) min= i;
                    if (numberdiapazon[i] > numberdiapazon[max]) max = i;
                }

                Console.WriteLine($"Nai malkoto chislo: {numberdiapazon[min]}, index: {min}");
                Console.WriteLine($"nai golqmoto chislo: {numberdiapazon[max]}, index: {max}");
            }
        }
    }
}
