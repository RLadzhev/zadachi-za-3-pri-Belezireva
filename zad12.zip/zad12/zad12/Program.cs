﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad12
{
    internal class Program
    {
        static void Main(string[] args)
        { 
            Console.Write("Въведете дума: ");
            string duma = Console.ReadLine();
            string obratnaduma = new string(duma.Reverse().ToArray());
            Console.WriteLine(obratnaduma);
        }
    }
}
