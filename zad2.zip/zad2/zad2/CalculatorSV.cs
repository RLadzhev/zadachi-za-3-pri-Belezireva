﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad2
{
    public class CalculatorSV
    {
        public double Radius { get; set; }
        public double Visochina { get; set; }
        public void CalculatePulnaPovurhnina()
        {
            double pi = 3.14;
            double S= 2* pi*Radius*Radius+ 2 *pi*Radius* Visochina;
            Console.WriteLine("Lice:" + S);

        }
        public void CalculateObem()
        {
            double pi = 3.14;
            double V =pi*Radius*Radius*Visochina;
            Console.WriteLine("Obem:"+V);
        }
    }
}
