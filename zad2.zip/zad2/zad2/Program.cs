﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CalculatorSV calculatorSV = new CalculatorSV();

            Console.Write("Radius=");
            calculatorSV.Radius=double.Parse(Console.ReadLine());
            Console.Write("Visochina=");
            calculatorSV.Visochina=double.Parse(Console.ReadLine());

            calculatorSV.CalculatePulnaPovurhnina();
            calculatorSV.CalculateObem();
        }
    }
}
