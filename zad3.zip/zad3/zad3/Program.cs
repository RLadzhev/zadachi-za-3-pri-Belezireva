﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Vuvedi chisla=");
            string chisla = Console.ReadLine();
            for(int i = 0; i < chisla.Length; i++)
            {
            Console.WriteLine(chisla[i]);
            }
        }
    }
}
