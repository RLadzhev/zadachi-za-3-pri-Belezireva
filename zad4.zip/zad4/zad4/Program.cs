﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Vuvedi chisla=");
            string chisla=Console.ReadLine();
            int[]numbers= chisla.Split(' ').Select(int.Parse).ToArray();
            Array.Sort(numbers);
            Console.WriteLine(string.Join("<", numbers));
        }
    }
}
