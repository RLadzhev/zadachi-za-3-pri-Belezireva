﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad5
{
    public class ChetnoChislo
    {
       
        public bool IsPrime(int number)
        {
            if (number < 2) return false;
            for (int i = 2; i <= Math.Sqrt(number); i++)
                if (number % i == 0) return false;
            return true;
        }

        public bool IsOdd(int number) => number % 2 != 0;

        public void Print(int number)
        {
            Console.Write($"Числото {number}: ");

            if (IsPrime(number))
                Console.Write("просто");
            else
                Console.Write("НЕ е просто");

            Console.Write(", ");

            if (IsOdd(number))
                Console.WriteLine("НЕ е четно");
            else
                Console.WriteLine("четно");
        }
    }
}
