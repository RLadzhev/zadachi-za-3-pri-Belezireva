﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Въведете числа, разделени със запетая:");
            string chislo = Console.ReadLine();
            string[] numbers = chislo.Split(',');

            ChetnoChislo chetnochislo = new ChetnoChislo();
            foreach (string num in numbers)
            {
                if (int.TryParse(num, out int n))
                    chetnochislo.Print(n);
            }

        }
    }
}
