﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Console.Write("Въведи a1: ");
            double a1 = double.Parse(Console.ReadLine());
            Console.Write("Въведи d: ");
            double d = double.Parse(Console.ReadLine());
            Console.Write("Въведи N: ");
            int n = int.Parse(Console.ReadLine());

            double sum = 0;
            Console.WriteLine("Редицата: ");
            for (int i = 0; i < n; i++)
            {
                double element = a1 + i * d;
                sum = sum + element;
                Console.Write(element + " ");
            }

          
            Console.WriteLine($"Сумата Sn: {sum}");

           
            if (n % 2 == 1)
            {
                Console.WriteLine($"Среден член: {a1 + (n / 2) * d}");
            }
            else
            {
                double sr1 = a1 + (n / 2 - 1) * d;
                double sr2 = a1 + (n / 2) * d;
                Console.WriteLine($"Средни членове: ({sr1} + {sr2}) / 2 = {(sr1 + sr2) / 2}");
            }
        }
    }
}
