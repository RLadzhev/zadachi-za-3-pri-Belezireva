﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int nulevi = 0;
            int neNulevi = 0;
            Console.WriteLine("vuvedi chisla ");
            int[] numbers=new int[20];
            for (int i = 0; i < numbers.Length; i++)
            {
                Console.Write($"Число {i + 1}: ");
                numbers[i] = int.Parse(Console.ReadLine());

                if (numbers[i] == 0)
                {
                    nulevi++;
                }
                else
                {
                    neNulevi += numbers[i];
                }
            }
            Console.WriteLine("Obshto nuli "+nulevi);
            Console.WriteLine("Sbora na Nenulevi e  "+neNulevi);

        }
    }
}
