﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int otricatelni = 0;
            int n = 0;
            int number;
            do
            {
                Console.WriteLine("Chislo:");
                number = int.Parse(Console.ReadLine());
                if (number != 0)
                {
                    n++;
                    if (number < 0)
                    {
                        otricatelni++;
                    }
                }
            }
            while (number != 0);
            {
                Console.WriteLine("Otricatelnite chisla sa "+otricatelni);
            }
        }
    }
}
