﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведи a: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("Въведи b: ");
            int b = int.Parse(Console.ReadLine());

            List<int> numbers = new List<int>();
            if (a <= b)
            {
                for (int i = a; i <= b; i++)
                {
                    numbers.Add(i);
                }
            }
            else
            {
                for (int i = a; i >= b; i--)
                {
                    numbers.Add(i);
                }
            }

            int sum = 0;
            foreach (int num in numbers)
            {
                sum += num;
            }
            Console.WriteLine($"Сумата на числата е: {sum}");

            int product = 1;
            foreach (int num in numbers)
            {
                product *= num;
            }
            Console.WriteLine($"Произведението на числата е: {product}");

            List<int> primes = new List<int>();
            foreach (int num in numbers)
            {
                if (num > 1)
                {
                    bool isPrime = true;
                    for (int i = 2; i <= Math.Sqrt(num); i++)
                    {
                        if (num % i == 0)
                        {
                            isPrime = false;
                            break;
                        }
                    }
                    if (isPrime)
                    {
                        primes.Add(num);
                    }
                }
            }
            Console.WriteLine("Простите числа са: " + string.Join(", ", primes));
        }
    }
}
